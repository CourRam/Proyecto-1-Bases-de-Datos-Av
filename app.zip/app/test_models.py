# test_models.py
from models import *
from database import init_app
from config import Config
from flask import Flask

# Crear app de Flask para contexto
app = Flask(__name__)
app.config.from_object(Config)
init_app(app)

with app.app_context():
    print("=" * 50)
    print("PRUEBA DE MODELOS")
    print("=" * 50)
    
    # 1. Probar obtener categorías
    categories = get_all_categories()
    print(f"\n✅ Categorías: {len(categories)}")
    
    # 2. Probar obtener tags
    tags = get_all_tags()
    print(f"✅ Tags: {len(tags)}")
    
    # 3. Probar registro de usuario
    result = register_user("Test User", "test7@email.com", "password123")
    print(f"\n✅ Registro: {result['message']}")
    # 4. Probar login
    login_result = login_user("test2@email.com", "password123")
    print(f"✅ Login: user_id = {login_result}")

    if result['success']:
        user_id = result['user_id']
        
        # 4. Probar login
        login_result = login_user("test2@email.com", "password123")
        print(f"✅ Login: user_id = {login_result}")
        
        # 5. Probar crear artículo (usando primera categoría)
        if categories:
            cat_id = categories[0]['CATEGORY_ID']
            tag_ids = ",".join([str(t['TAG_ID']) for t in tags[:2]])  # Primeros 2 tags
            
            article_result = create_article(
                user_id=user_id,
                category_id=cat_id,
                title="Mi Primer Artículo",
                text="Este es el contenido de mi primer artículo en el blog.",
                tag_ids=tag_ids
            )
            print(f"✅ Crear artículo: {article_result['message']}")
            
            # 6. Probar obtener artículos
            articles = get_articles()
            print(f"✅ Total artículos: {len(articles)}")
            
            # 7. Probar agregar comentario (si se creó el artículo)
            if article_result['success']:
                comment_result = add_comment(
                    user_id=user_id,
                    article_id=article_result['article_id'],
                    text="¡Excelente artículo! Me encantó."
                )
                print(f"✅ Agregar comentario: {comment_result['message']}")
    
    print("\n" + "=" * 50)
    print("PRUEBAS COMPLETADAS")
    print("=" * 50)