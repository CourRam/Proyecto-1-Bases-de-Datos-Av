from database import get_db, execute_function, fetch_all
from config import Config
import oracledb
from flask import Flask

# Crear app de Flask para contexto
app = Flask(__name__)
app.config.from_object(Config)

with app.app_context():
    # Probar conexión
    db = get_db()
    if db:
        print("✅ Conexión exitosa a Oracle")
        
        # Probar obtener categorías
        categories = fetch_all('get_all_categories')
        print(f"📊 Categorías encontradas: {len(categories)}")
        for cat in categories:
            print(f"  - {cat['NAME']} (/{cat['URL']})")
        
        # Probar obtener tags
        tags = fetch_all('get_all_tags')
        print(f"🏷️ Tags encontrados: {len(tags)}")
        for tag in tags:
            print(f"  - {tag['NAME']} (/{tag['URL']})")
    else:
        print("❌ Error de conexión")