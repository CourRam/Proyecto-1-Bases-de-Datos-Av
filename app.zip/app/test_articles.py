# test_articles.py
from models import debug_articles, get_article_by_url
from database import init_app
from config import Config
from flask import Flask

app = Flask(__name__)
app.config.from_object(Config)
init_app(app)

with app.app_context():
    # Ver todos los artículos
    articles = debug_articles()
    
    # Si hay artículos, probar el primero
    if articles:
        first_url = articles[0].get('URL')
        print(f"\nProbando buscar artículo con URL: {first_url}")
        article_data = get_article_by_url(first_url)
        if article_data and article_data['article']:
            print(f"✅ Éxito: {article_data['article']['TITLE']}")
        else:
            print("❌ Error: No se pudo recuperar el artículo")